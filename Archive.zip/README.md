# NEAT-Pong-Python
Using the NEAT algorithm to train an AI to play pong in Python!
